# 部署到公网（发给朋友玩）

这个文件夹就是可以直接上传的静态站点：

- `index.html` —— 整个游戏（HTML + CSS + JS 全部内联，没有别的依赖）
- `share.jpg` —— 分享卡片图（`og:image` 用）
- `README.md` —— 本说明

**不需要服务器、数据库、后端或构建步骤**，把文件夹传上去就能玩。任选下面一种方式。

---

## 方案一：Netlify Drop（最快，约 1 分钟）

1. 打开 <https://app.netlify.com/drop>
2. 把整个 `deploy` 文件夹（或 `每日拼图-部署包.zip`）拖进页面
3. 等几秒，得到一个 `https://xxxx.netlify.app` 链接，直接发给朋友
4. 想长期保留 / 改个好记的名字：按提示注册登录，`Site settings → Change site name`

## 方案二：GitHub Pages（免费、稳定）

1. 注册 / 登录 <https://github.com>
2. 右上角 `New repository` → 名字如 `daily-puzzle` → 选 `Public` → `Create repository`
3. 仓库页 `Add file → Upload files`，把 `index.html` 和 `share.jpg` 拖进去 → `Commit changes`
4. `Settings → Pages → Build and deployment`：Source 选 `Deploy from a branch`，Branch 选 `main` + `/(root)` → `Save`
5. 等 1 分钟左右，访问：

   ```
   https://你的用户名.github.io/daily-puzzle/
   ```

## 方案三：Cloudflare Pages（全球 CDN，速度不错）

1. 登录 <https://dash.cloudflare.com>
2. `Workers & Pages → Create → Pages → Upload assets`
3. 项目名如 `daily-puzzle`，上传 `deploy` 文件夹里的两个文件 → `Deploy`
4. 得到 `https://daily-puzzle.pages.dev`

## 方案四：Vercel（本机有 Node 时）

```bash
cd deploy
npx vercel --prod
```

按提示登录，得到 `https://xxx.vercel.app`。

---

## 先在局域网里试玩

```bash
cd deploy
python -m http.server 8000
```

- 电脑浏览器打开 <http://127.0.0.1:8000>
- 手机连同一个 Wi-Fi，打开 `http://电脑的局域网IP:8000`（`ipconfig` 里看 IPv4；Windows 防火墙弹窗点“允许”）

---

## 常见问题

**进度存在哪里？**
每个访客自己浏览器的 localStorage 里，按日期分别保存。换设备、清缓存会丢，互相不影响，也不需要服务器。

**大家看到的是同一天吗？**
页面用访客设备的本地日期，所以每个人看到自己的“今天”。想固定某一天玩，可以加参数：`?date=2026-03-27`（例如 `https://xxx.pages.dev/?date=2026-03-27`）。

**国内访问速度？**
GitHub Pages / Netlify / Cloudflare 在国内速度不太稳定。要稳定 + 自定义域名，建议用腾讯云 COS 或阿里云 OSS 的“静态网站托管” + 已备案域名（注意：阿里云 OSS 默认域名会强制下载 HTML，需要绑定自定义域名）。

**微信里能玩吗？**
能。直接把 https 链接发过去，微信内置浏览器可以运行；如果提示“在浏览器打开”，用系统浏览器打开也一样。

**分享卡片（微信/QQ/Twitter 的预览图）**
`index.html` 里已经写好 `og:title`、`og:description`、`og:image`（指向 `share.jpg`）。如果换域名或想用自己的图，改这三行即可。部分平台要求 `og:image` 是绝对地址，可以改成 `https://你的域名/share.jpg`。

**安全吗？**
纯静态页面：没有后端、没有接口、没有统计和第三方脚本，不会收集任何数据。

**要不要 HTTPS？**
上面几种托管都自带 HTTPS，不用自己配证书。
